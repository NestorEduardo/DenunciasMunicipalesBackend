﻿namespace ATM
{
    partial class frmATM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmATM));
            this.lblAvaliableAmount = new System.Windows.Forms.Label();
            this.btnTwoThousand = new System.Windows.Forms.Button();
            this.btnOneThousand = new System.Windows.Forms.Button();
            this.btnFiveHundred = new System.Windows.Forms.Button();
            this.btnTwoHundred = new System.Windows.Forms.Button();
            this.btnOneHundred = new System.Windows.Forms.Button();
            this.btnFifty = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblAvaliableAmount
            // 
            this.lblAvaliableAmount.AutoSize = true;
            this.lblAvaliableAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAvaliableAmount.Location = new System.Drawing.Point(75, 18);
            this.lblAvaliableAmount.Name = "lblAvaliableAmount";
            this.lblAvaliableAmount.Size = new System.Drawing.Size(130, 16);
            this.lblAvaliableAmount.TabIndex = 0;
            this.lblAvaliableAmount.Text = "Balance disponible: ";
            // 
            // btnTwoThousand
            // 
            this.btnTwoThousand.Location = new System.Drawing.Point(16, 78);
            this.btnTwoThousand.Name = "btnTwoThousand";
            this.btnTwoThousand.Size = new System.Drawing.Size(83, 32);
            this.btnTwoThousand.TabIndex = 1;
            this.btnTwoThousand.Text = "2000";
            this.btnTwoThousand.UseVisualStyleBackColor = true;
            this.btnTwoThousand.Click += new System.EventHandler(this.btnTwoThousand_Click);
            // 
            // btnOneThousand
            // 
            this.btnOneThousand.Location = new System.Drawing.Point(105, 78);
            this.btnOneThousand.Name = "btnOneThousand";
            this.btnOneThousand.Size = new System.Drawing.Size(83, 32);
            this.btnOneThousand.TabIndex = 2;
            this.btnOneThousand.Text = "1000";
            this.btnOneThousand.UseVisualStyleBackColor = true;
            this.btnOneThousand.Click += new System.EventHandler(this.btnOneThousand_Click);
            // 
            // btnFiveHundred
            // 
            this.btnFiveHundred.Location = new System.Drawing.Point(194, 78);
            this.btnFiveHundred.Name = "btnFiveHundred";
            this.btnFiveHundred.Size = new System.Drawing.Size(83, 32);
            this.btnFiveHundred.TabIndex = 3;
            this.btnFiveHundred.Text = "500";
            this.btnFiveHundred.UseVisualStyleBackColor = true;
            this.btnFiveHundred.Click += new System.EventHandler(this.btnFiveHundred_Click);
            // 
            // btnTwoHundred
            // 
            this.btnTwoHundred.Location = new System.Drawing.Point(15, 116);
            this.btnTwoHundred.Name = "btnTwoHundred";
            this.btnTwoHundred.Size = new System.Drawing.Size(83, 32);
            this.btnTwoHundred.TabIndex = 4;
            this.btnTwoHundred.Text = "200";
            this.btnTwoHundred.UseVisualStyleBackColor = true;
            this.btnTwoHundred.Click += new System.EventHandler(this.btnTwoHundred_Click);
            // 
            // btnOneHundred
            // 
            this.btnOneHundred.Location = new System.Drawing.Point(105, 116);
            this.btnOneHundred.Name = "btnOneHundred";
            this.btnOneHundred.Size = new System.Drawing.Size(83, 32);
            this.btnOneHundred.TabIndex = 5;
            this.btnOneHundred.Text = "100";
            this.btnOneHundred.UseVisualStyleBackColor = true;
            this.btnOneHundred.Click += new System.EventHandler(this.btnOneHundred_Click);
            // 
            // btnFifty
            // 
            this.btnFifty.Location = new System.Drawing.Point(194, 116);
            this.btnFifty.Name = "btnFifty";
            this.btnFifty.Size = new System.Drawing.Size(83, 32);
            this.btnFifty.TabIndex = 6;
            this.btnFifty.Text = "50";
            this.btnFifty.UseVisualStyleBackColor = true;
            this.btnFifty.Click += new System.EventHandler(this.btnFifty_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(113, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 16);
            this.label1.TabIndex = 7;
            this.label1.Text = "Retiros";
            // 
            // frmATM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(321, 204);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnFifty);
            this.Controls.Add(this.btnOneHundred);
            this.Controls.Add(this.btnTwoHundred);
            this.Controls.Add(this.btnFiveHundred);
            this.Controls.Add(this.btnOneThousand);
            this.Controls.Add(this.btnTwoThousand);
            this.Controls.Add(this.lblAvaliableAmount);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmATM";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "ATM";
            this.Load += new System.EventHandler(this.frmATM_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAvaliableAmount;
        private System.Windows.Forms.Button btnTwoThousand;
        private System.Windows.Forms.Button btnOneThousand;
        private System.Windows.Forms.Button btnFiveHundred;
        private System.Windows.Forms.Button btnTwoHundred;
        private System.Windows.Forms.Button btnOneHundred;
        private System.Windows.Forms.Button btnFifty;
        private System.Windows.Forms.Label label1;
    }
}