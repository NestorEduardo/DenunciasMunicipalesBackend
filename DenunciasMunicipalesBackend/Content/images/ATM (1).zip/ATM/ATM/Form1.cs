﻿using System;
using System.Windows.Forms;

namespace ATM
{
    public partial class frmStartup : Form
    {
        private int operation = 0;

        public frmStartup()
        {
            InitializeComponent();
        }

        private void frmStartup_Load(object sender, EventArgs e)
        {
            lblMessage.Text = "Ingrese su número de cuenta";
        }

        private void WriteNumber(string number)
        {
            txtScreen.Text += number;
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            WriteNumber("1");
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            WriteNumber("2");
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            WriteNumber("3");
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            WriteNumber("4");
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            WriteNumber("5");
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            WriteNumber("6");
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            WriteNumber("7");
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            WriteNumber("8");
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            WriteNumber("9");
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            WriteNumber("0");
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            txtScreen.Clear();
            EnableButtons();
        }

        private void CheckAccount(string account)
        {
            if (account == "1234567890")
            {
                operation = 1;
                lblMessage.Text = "Ingrese su clave";
                txtScreen.Clear();
            }
            else
            {
                txtScreen.Clear();
                MessageBox.Show("Número de cuenta incorrecto.");
            }

            EnableButtons();
        }

        private void CheckPassword(string password)
        {
            operation = 1;

            if (txtScreen.TextLength == 4)
            {

                if (password == "1234")
                {
                    frmATM Fatm = new frmATM();
                    Fatm.Show();
                    Hide();
                }
                else
                {
                    txtScreen.Clear();
                    MessageBox.Show("Clave incorrecta.");
                    EnableButtons();
                }
            }
        }

        private void txtScreen_TextChanged(object sender, EventArgs e)
        {
            if (operation == 0)
            {
                if (txtScreen.TextLength == 10)
                {
                    DisableButtons();
                    EnableAcceptButton();
                }
                else
                {
                    DisableAcceptButton();
                }
            }
            else
            {
                if (txtScreen.TextLength == 4)
                {
                    DisableButtons();
                    EnableAcceptButton();
                }
                else
                {
                    DisableAcceptButton();
                }
            }


            if (txtScreen.Text != string.Empty)
            {
                EnableClearButton();
            }
            else
            {
                DisableClearButton();
            }
        }

        private void EnableButtons()
        {
            btn1.Enabled = true;
            btn2.Enabled = true;
            btn3.Enabled = true;
            btn4.Enabled = true;
            btn5.Enabled = true;
            btn6.Enabled = true;
            btn7.Enabled = true;
            btn8.Enabled = true;
            btn9.Enabled = true;
            btn0.Enabled = true;
        }

        private void DisableButtons()
        {
            btn1.Enabled = false;
            btn2.Enabled = false;
            btn3.Enabled = false;
            btn4.Enabled = false;
            btn5.Enabled = false;
            btn6.Enabled = false;
            btn7.Enabled = false;
            btn8.Enabled = false;
            btn9.Enabled = false;
            btn0.Enabled = false;
        }

        private void EnableClearButton()
        {
            btnDelete.Enabled = true;
        }

        private void DisableClearButton()
        {
            btnDelete.Enabled = false;
        }

        private void EnableAcceptButton()
        {
            btnAccept.Enabled = true;
        }

        private void DisableAcceptButton()
        {
            btnAccept.Enabled = false;
        }

        private void btnAccept_Click(object sender, EventArgs e)
        {
            if (operation == 0)
            {
                CheckAccount(txtScreen.Text);
            }

            if (operation == 1)
            {
                CheckPassword(txtScreen.Text);
            }
        }
    }
}
