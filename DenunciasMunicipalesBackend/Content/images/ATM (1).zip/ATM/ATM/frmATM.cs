﻿using System.Windows.Forms;

namespace ATM
{
    public partial class frmATM : Form
    {
        int amountAvaliable = 10000;

        public frmATM()
        {
            InitializeComponent();
        }

        private void frmATM_Load(object sender, System.EventArgs e)
        {
            lblAvaliableAmount.Text = "Balance disponible: "  + amountAvaliable;
        }

        private void Withdraw(int amount)
        {
            DialogResult dialogResult = MessageBox.Show("¿Está seguro de retirar este monto?", "Confirmación", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes)
            {
                amountAvaliable -= amount;
                lblAvaliableAmount.Text = "Balance disponible: " + amountAvaliable;
            }
        }

        private void CheckEnoughValance(int amount)
        {
            if (amount > amountAvaliable)
            {
                MessageBox.Show("Usted no tiene suficiente balance para hacer este retiro", "Error");
            }
            else
            {
                Withdraw(amount);
            }
        }

        private void btnTwoThousand_Click(object sender, System.EventArgs e)
        {
            CheckEnoughValance(2000);
        }

        private void btnOneThousand_Click(object sender, System.EventArgs e)
        {
            CheckEnoughValance(1000);
        }

        private void btnFiveHundred_Click(object sender, System.EventArgs e)
        {
            CheckEnoughValance(500);
        }

        private void btnTwoHundred_Click(object sender, System.EventArgs e)
        {
            CheckEnoughValance(200);
        }

        private void btnOneHundred_Click(object sender, System.EventArgs e)
        {
            CheckEnoughValance(100);
        }

        private void btnFifty_Click(object sender, System.EventArgs e)
        {
            CheckEnoughValance(50);
        }
    }
}
